package com.example.pipesfilters;

public interface Filter {
    Object process(Object input);
}
